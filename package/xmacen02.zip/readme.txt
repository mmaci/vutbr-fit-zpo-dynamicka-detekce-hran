Pot�ebn� DLL:

icuin49.dll
libEGLd.dll
libGLESv2d.dll
Qt5Cored.dll
Qt5Guid.dll
Qt5Widgetsd.dll

nach�z� se ve standartn� instalaci Qt, pop�. jsou ke sta�en� z na�eho repozit��e:
https://github.com/mmaci/vutbr-fit-zpo-dynamicka-detekce-hran